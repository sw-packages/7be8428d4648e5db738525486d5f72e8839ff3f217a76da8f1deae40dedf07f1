// Copyright (C) 2022 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR GPL-3.0-only

#include "qwaylandcompositorquickextensions_p.h"

QT_BEGIN_NAMESPACE

QT_END_NAMESPACE

#include "moc_qwaylandcompositorquickextensions_p.cpp"
